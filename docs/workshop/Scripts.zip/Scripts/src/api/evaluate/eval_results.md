|    | research_context                                                               |   gpt_relevance |   gpt_fluency |   gpt_coherence |   gpt_groundedness |
|---:|:-------------------------------------------------------------------------------|----------------:|--------------:|----------------:|-------------------:|
|  0 | Can you find the latest camping trends and what folks are doing in the winter? |               5 |             5 |               5 |                  5 |
|  1 | Can you find the latest trends in hiking shoes?                                |               5 |             5 |               5 |                  1 |
|  2 | Find information about the best snow camping spots in the world                |               5 |             5 |               5 |                  1 |

Averages scores:

|                  |       0 |
|:-----------------|--------:|
| gpt_relevance    | 5       |
| gpt_fluency      | 5       |
| gpt_coherence    | 5       |
| gpt_groundedness | 2.33333 |